import { useState } from "react";
import { useRouter } from "next/router";

export default function Login() {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");
  const router = useRouter();

  const handleLogin = (e) => {
    e.preventDefault();

    const emailAdmin = "andradecorreafinanceira@gmail.com";
    const senhaAdmin = "acfin0902";

    if (email === emailAdmin && senha === senhaAdmin) {
      router.push("/dashboard");
    } else {
      setErro("E-mail ou senha incorretos.");
    }
  };

  const handleEsqueciSenha = () => {
    alert("Entre em contato com o suporte para redefinir sua senha: (48) 98857-0984");
  };

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center">
      <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-sm">
        <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">Login AC Financeira</h2>
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">E-mail</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Senha</label>
            <input
              type="password"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              className="mt-1 w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
              required
            />
          </div>
          {erro && <p className="text-red-500 text-sm text-center">{erro}</p>}
          <button
            type="submit"
            className="w-full bg-orange-500 hover:bg-orange-600 text-white py-2 px-4 rounded-lg"
          >
            Entrar
          </button>
        </form>
        <button
          onClick={handleEsqueciSenha}
          className="mt-4 text-sm text-orange-500 hover:underline w-full text-center"
        >
          Esqueci minha senha
        </button>
      </div>
    </div>
  );
}
